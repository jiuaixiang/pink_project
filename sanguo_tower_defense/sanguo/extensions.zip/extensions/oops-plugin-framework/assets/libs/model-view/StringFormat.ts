import { LanguageData } from '../gui/language/LanguageData';

// 缓存正则表达式，避免重复创建
const REGEX_SEP = /(\d)(?=(\d{3})+$)/ig;

/**
 * 数值格式化函数, 通过语义解析自动设置值的范围
 * 1:def(0) // 显示一个默认值
 */
class StringFormat {
    deal(value: number | string, format: string): string {
        if (format === '') return value as string;

        format = format.toLowerCase().trim(); // 不区分大小
        const match_func = format.match(/^[a-z|A-Z]+/gi); // 匹配到 format 中的函数名
        const match_num = format.match(/\d+$/gi); // 匹配到 format 中的参数
        let func = '';
        let num = 0;
        let res: number | string = '';

        if (match_func) func = match_func[0];
        if (match_num) num = parseInt(match_num[0]);

        if (typeof value === 'number') {
            switch (func) {
            case 'int': res = this.int(value); break;
            case 'fix': res = this.fix(value, num); break;
            case 'kmbt': res = this.kmbt(value); break;
            case 'per': res = this.per(value, num); break;
            case 'sep': res = this.sep(value); break;

            case 'stamp': res = this.time_stamp(value); break;
            case 'ms': res = this.time_ms(value); break;
            case 'hms': res = this.time_hms(value); break;
            case 'hmss': res = this.time_hmss(value); break;

            default: break;
            }
        }
        else {
            switch (func) {
            case 'limit': res = this.limit(value, num); break;
            default:
                break;
            }
            res = value;
        }

        return res as string;
    }

    /** 将数字按分号显示 */
    private sep(value: number) {
        const num = Math.round(value).toString();
        // 使用缓存的正则表达式
        return num.replace(REGEX_SEP, '$1,');
    }

    /** 将数字按分显示 00:00 显示 （分:秒） */
    private time_ms(value: number) {
        // 使用数学计算代替 Date 对象创建，性能更好
        const totalSeconds = Math.floor(value / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }

    /** 将数字按秒显示 00:00:00 显示 （时:分:秒） */
    private time_hms(value: number) {
        const totalSeconds = Math.floor(value / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }

    /** 将数字按 0:00:00:000 显示 （时:分:秒:毫秒） */
    private time_hmss(value: number) {
        const totalSeconds = Math.floor(value / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const ms = value % 1000;
        return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}:${String(ms).padStart(3, '0')}`;
    }

    /** 将时间戳显示为详细的内容 */
    private time_stamp(value: number) {
        // Date 对象在此处是必需的，因为需要格式化完整日期
        return new Date(value).format('yy-mm-dd hh:mm:ss');
    }

    /** [value:int] 将取值0~1 变成 1~100,可以指定修饰的小数位数 */
    private per(value: number, fd: number) {
        const r = value * 100;
        return r.toFixed(fd);
    }

    /** [value:int] 将取值变成整数 */
    private int(value: number) {
        return Math.round(value);
    }

    /** [value:fix2]数值转换为小数 */
    private fix(value: number, fd: number) {
        return value.toFixed(fd);
    }

    /** [value:limit3]字符串长度限制 */
    private limit(value: string, count: number) {
        return value.substring(0, count);
    }

    /** 将数字缩短显示为KMBT单位 大写,目前只支持英文 */
    private kmbt(value: number) {
        //10^4=万, 10^8=亿,10^12=兆,10^16=京，
        let counts: number[] = null!;
        let units: string[] = null!;

        switch (LanguageData.current) {
        case 'zh':
            //10^4=万, 10^8=亿,10^12=兆,10^16=京，
            counts = [10000, 100000000, 1000000000000, 10000000000000000];
            units = ['', '万', '亿', '兆', '京'];
            break;
        default:
            counts = [1000, 1000000, 1000000000, 1000000000000];
            units = ['', 'K', 'M', 'B', 'T'];
            break;
        }

        return this.compressUnit(value, counts, units, 2);
    }

    /** 压缩任意单位的数字，后缀加上单位文字 */
    private compressUnit(value: any, valueArr: number[], unitArr: string[], fixNum = 2): string {
        const counts = valueArr;
        const units = unitArr;
        let res = '';
        let index: number;
        for (index = 0; index < counts.length; index++) {
            const e = counts[index];
            if (value < e) {
                if (index > 0) {
                    res = (value / counts[index - 1]).toFixed(fixNum);
                }
                else {
                    res = value.toFixed(0);
                }
                break;
            }
        }
        return res + units[index];
    }
}

/** 格式化处理函数 */
export const StringFormatFunction = new StringFormat();
